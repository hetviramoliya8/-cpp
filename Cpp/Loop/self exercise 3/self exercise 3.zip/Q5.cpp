#include <iostream>
using namespace std;

int main() {

    for (int i = 1; i <= 3; ++i) {
        cout << i << " ";
    }
    cout << endl;


    for (int i = 4; i >= 1; --i) {
        cout << i;
    }
    for (int i = 2; i <= 4; ++i) {
        cout << i;
    }
    cout << endl;
}
